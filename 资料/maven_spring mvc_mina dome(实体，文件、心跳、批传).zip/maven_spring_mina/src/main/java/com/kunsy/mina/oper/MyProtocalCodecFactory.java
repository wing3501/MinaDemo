package com.kunsy.mina.oper;

import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolEncoder;

/**
 *  mina ���롢���빤��
 *Ginkery
 * @author liumy
 *2012-11-2 ����3:35:16
 * @email: kunsyliu@aliyun.com
 * com.ginkery.mina.oper
 * 此工厂只是用于小文件（几十mb吧，不然会抛内存溢出错误，对于大文件传输，必须边读边写）（个人看法未验证）
 *
 */
public class MyProtocalCodecFactory   implements ProtocolCodecFactory {  
        private final MyProtocalEncoder encoder;  //编码
        private final MyProtocalDecoder decoder;  //解码
          
        public MyProtocalCodecFactory(String charset) {  
            encoder=new MyProtocalEncoder(charset);  
            decoder=new MyProtocalDecoder(charset);  
        }  
           
        public ProtocolEncoder getEncoder(IoSession session) {  
            return encoder;  
        }  
        public ProtocolDecoder getDecoder(IoSession session) {  
            return decoder;  
        }  
          
} 