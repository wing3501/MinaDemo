package com.kunsy.mina.service;

import java.io.IOException;
import java.net.InetSocketAddress;

import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;

import com.kunsy.mina.oper.MyProtocalCodecFactory;

public class ServiceMinaMain {
	public static void main(String args[])
	{
		NioSocketAcceptor acceptor=new NioSocketAcceptor();
		acceptor.getFilterChain().addLast("code",new ProtocolCodecFilter(new MyProtocalCodecFactory("utf-8")));
		acceptor.getSessionConfig().setIdleTime(IdleStatus.BOTH_IDLE, 2);
		acceptor.setHandler(new MinaImageHander());
		try {
			acceptor.bind(new InetSocketAddress(1235));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
