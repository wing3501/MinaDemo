package com.kunsy.mina.client;

import java.io.FileOutputStream;

import org.apache.mina.core.service.IoHandler;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSession;

import com.kunsy.mina.eneity.Message;

public class minaImageHander implements IoHandler {
	public static int i=0;

	public void exceptionCaught(IoSession arg0, Throwable arg1)
			throws Exception {
		arg1.printStackTrace();

	}

	public void messageReceived(IoSession session, Object message) throws Exception {
		System.out.println("接收到服务端消息：");
		Message mes= (Message) message;
		if(mes.getType()==1||mes.getType()==0){
			System.out.println("接收到服务端数据包：");
			System.out.println("图片长度"+mes.getAlonght());
			System.out.println("imagename:"+mes.getImagename());
			System.out.println("图片信息"+mes.getImagelongth());
			//FileChannel fc=out.getChannel();
			System.out.println("收到几个完整数据："+i);
			new FileOutputStream("d:\\image"+(i++)+".jpg").write(mes.getImage());
		}
		/*应该接收到心跳包给服务端返回响应，但为了测试服务端在长时间为收到客户端消息会自动关闭连接，所以注释掉下面代码。（向服务端返回相应(Header.java)表示你还没死）*/
	/*	else if(mes.getType()==2){
			System.out.println("接收到服务端心跳包：");
			IoBuffer io = IoBuffer.allocate(8);
			io.putInt(8);
			io.putInt(2);
			io.flip();
			session.write(io);
		}*/
	}

	public void messageSent(IoSession arg0, Object arg1) throws Exception {

	}

	public void sessionClosed(IoSession arg0) throws Exception {
		System.out.println("关闭连接："+arg0);
	}


	public void sessionCreated(IoSession arg0) throws Exception {

	}

	/*当设置了idletime时，会定时调用该方法*/
	public void sessionIdle(IoSession arg0, IdleStatus arg1) throws Exception {
		System.out.println("客户端调用了idle……");
		/*客户端可以在此处主动发起心跳，代码：……。
		 * 当然自己在某处根据时间写心跳也可以，只是本人觉得没必要
		 * */
	}


	public void sessionOpened(IoSession arg0) throws Exception {
		System.out.println("与服务端建立连接session："+arg0);

	}

}
