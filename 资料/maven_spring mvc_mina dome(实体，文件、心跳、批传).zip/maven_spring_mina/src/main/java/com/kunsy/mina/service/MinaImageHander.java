package com.kunsy.mina.service;

import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.service.IoHandler;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSession;

import com.kunsy.mina.eneity.Header;
import com.kunsy.mina.eneity.Message;

public class MinaImageHander implements IoHandler {

	public void exceptionCaught(IoSession arg0, Throwable arg1)
			throws Exception {
		arg1.printStackTrace();

	}

	public void messageReceived(IoSession session, Object message)
			throws Exception {
		Message m = (Message) message;
		if (m.getType() == 2) {
			System.out.println("接收到客户端心跳包………………");
		} else {
			System.out.println("接收到客户端数据包………………");
		}
		session.setAttribute("receivetime", System.currentTimeMillis());
	}

	public void messageSent(IoSession session, Object arg1) throws Exception {
	}
	/*在关闭连接时调用，包括自己关闭和客户端关闭*/
	public void sessionClosed(IoSession session) throws Exception {
		/*表明客户端已下线，某些地方需要验证，所以记录下来*/
		session.setAttribute("islive", false);	
	}

	public void sessionCreated(IoSession arg0) throws Exception {

	}
	/*当设置了idletime时，会定时调用该方法*/
	public void sessionIdle(IoSession session, IdleStatus arg1)
			throws Exception {
		System.out.println("服务端调用了idle……，发送心跳包，验证客户端是否荏苒存活");
	/*	心跳包只需要包含一个数据包基本信息（头信息），需要身份验证的话一并放入头中*/
		Header h = new Header();
		h.setAlonght(4 + 4);
		h.setType(2);
		IoBuffer io = IoBuffer.allocate(8);
		io.putInt(8);
		io.putInt(2);
		io.flip();
		session.write(io);
		Long lastrecesivetime = (Long) session.getAttribute("receivetime");
		Long nowtime = System.currentTimeMillis();
		/*在收到客户端数据包时记录最近收到时间*/
		System.out.println("最近发送时间：" + lastrecesivetime);
		System.out.println("等待时间：" + (nowtime - lastrecesivetime));
		/*超过指定时间未收到客户端相应认为客户端已下线，单位毫秒*/
		if (nowtime - lastrecesivetime > 20000) {
			System.out.println("客户端以下线……");
			/*表明客户端已下线，某些地方需要验证，所以记录下来*/
			session.setAttribute("islive", false);
			session.close(true);// 主动关闭连接
		}

	}
/*消息发送放在什么位置都可以，自己觉得吧，注意发送一定要在连接建立成功后*/
	public void sessionOpened(final IoSession session) throws Exception {
		System.out.println("one client connect:" + session);
		session.setAttribute("receivetime", System.currentTimeMillis());
		System.out.println("最近发送时间" + session.getAttribute("receivetime"));
		session.setAttribute("islive", true);
		new Thread() {
			public void run() {
				for (int i = 0; i < 10; i++) {
					if (!(Boolean) session.getAttribute("islive")) {
						return;
					}
					try {
						Message mes = new Message();
						@SuppressWarnings("resource")
						FileChannel channel = new FileInputStream(
								"d:\\2013-01.jpg").getChannel();
						String jsonStr = "{\"ack\":\"true\", \"command\":\"中文乱码测试吃\", \"dcsn\":\"sn-001\", \"id\":\"2001\"}";
						mes.setImagename(jsonStr);
						/* 中文和英文转换成byte长度区域,注意获取长度时最好指定编码方式，不然可能会导致位数不对 */
						mes.setImagenamelongth(mes.getImagename().getBytes(
								"utf-8").length);
						ByteBuffer bytebuffer = ByteBuffer
								.allocate((int) channel.size());
						bytebuffer.clear();
						channel.read(bytebuffer);
						mes.setImagelongth(channel.size());
						mes.setImage(bytebuffer.array());
						mes.setAlonght((int) (4 + 4 + 4 + 8
								+ mes.getImagelongth() + mes
								.getImagenamelongth()));
						mes.setType(i == 9 ? 0 : 1);
						/*将mes交给编码工厂（过滤器链），进行编码处理*/
						session.write(mes);
						//Thread.sleep(5000);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}.start();

	}

}
