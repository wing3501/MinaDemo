package com.kunsy.mina.client;

import java.net.InetSocketAddress;




import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.nio.NioSocketConnector;

import com.kunsy.mina.oper.MyProtocalCodecFactory;

public class ClientMinaMain {
	public static void main(String args[])
	{
		NioSocketConnector conn=new NioSocketConnector();
		conn.getFilterChain().addLast("code",new ProtocolCodecFilter(new MyProtocalCodecFactory("utf-8")));
		conn.getSessionConfig().setIdleTime(IdleStatus.BOTH_IDLE, 2);
		conn.setHandler(new minaImageHander());
		conn.connect(new InetSocketAddress("127.0.0.1",1235));
		
	}

}
/*此项目主要目的是与spring mvc整合，所以放到web服务器下运行吧，注意maven jar 是否down下来了*/
