package com.kunsy.mina.oper;

import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;

import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolEncoderAdapter;
import org.apache.mina.filter.codec.ProtocolEncoderOutput;

import com.kunsy.mina.eneity.Message;

/**
 * �����࣬��Ҫ���͵���ݽ��б��룬��װ��byte���鷢�͵������
 * 
 *Ginkery
 * @author liumy
 *2012-11-2 ����3:40:06
 * @email: kunsyliu@aliyun.com
 * com.ginkery.mina.oper
 *
 */
public class MyProtocalEncoder extends ProtocolEncoderAdapter {
	private final String charset;
	public MyProtocalEncoder(String charset) {
		this.charset = charset;
	}

	/* 编码器，对接收到的object进行编码工作，然后交由下一个过滤器处理 */
	public void encode(IoSession session, Object message,
			ProtocolEncoderOutput out) throws Exception {
		System.out.println("进入编码器"+message);
		CharsetEncoder encoder = Charset.forName(charset).newEncoder();
		Message mes=(Message) message;
		IoBuffer io = IoBuffer.allocate(mes.getAlonght());
		io.clear();
		io.position(0);// 清空缓存并重置
		/* 写入顺序需要和读取顺序一致，才能正确解析 */
		io.putInt(mes.getAlonght());
		io.putInt(mes.getType());
		io.putInt(mes.getImagenamelongth());
		try {
			io.putString(mes.getImagename(), encoder);
		} catch (CharacterCodingException e1) {
			e1.printStackTrace();
		}
		io.putLong(mes.getImagelongth());
		io.put(mes.getImage());
		System.out.println("send remaining:" + io.limit());
		io.flip();
		
		out.write(io);
	}

	public void dispose() throws Exception {
	}
}
