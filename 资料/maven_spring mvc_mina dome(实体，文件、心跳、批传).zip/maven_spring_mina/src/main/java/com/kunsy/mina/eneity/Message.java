package com.kunsy.mina.eneity;

public class Message extends Header {
	//private int alonght;// 消息总长度
	private int imagenamelongth;// 图片名称长度
	private long imagelongth;// 图片长度（大小）
	private String imagename;// 图片名称（字符串，顺便测试json）
	private byte[] image;// 图片内容

	public int getImagenamelongth() {
		return imagenamelongth;
	}

	public void setImagenamelongth(int imagenamelongth) {
		this.imagenamelongth = imagenamelongth;
	}

	public long getImagelongth() {
		return imagelongth;
	}

	public void setImagelongth(long imagelongth) {
		this.imagelongth = imagelongth;
	}

	public String getImagename() {
		return imagename;
	}

	public void setImagename(String imagename) {
		this.imagename = imagename;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] image) {
		this.image = image;
	}

}
